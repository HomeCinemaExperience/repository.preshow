from hachoir.wx.main import main
main()
