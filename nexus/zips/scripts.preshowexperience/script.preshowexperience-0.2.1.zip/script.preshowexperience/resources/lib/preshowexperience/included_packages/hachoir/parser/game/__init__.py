from hachoir.parser.game.zsnes import ZSNESFile  # noqa
from hachoir.parser.game.spider_man_video import SpiderManVideoFile  # noqa
from hachoir.parser.game.laf import LafFile  # noqa
from hachoir.parser.game.blp import BLP1File, BLP2File  # noqa
