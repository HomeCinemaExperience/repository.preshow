class StreamError(Exception):
    pass
