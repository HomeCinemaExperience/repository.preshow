# PreShow Experience Kodi Add-on (script.preshowexperience)
*Movie theater preshow sxperience for your home!*

## Prerequisites
You must have a working install of [Kodi](http://kodi.tv/) to use this add-on.

## License
Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International Public License

## Acknowledgments
@Nuka1195 (Home Theatre Experience), @giftie (Cinema Experience), @ragnarok for creating the predecessors that inspired PreShow Experience.